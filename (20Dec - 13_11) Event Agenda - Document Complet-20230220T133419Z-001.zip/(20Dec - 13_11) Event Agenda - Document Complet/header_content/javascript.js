

$(document).ready(function(){
        $('#show1').click(function() {
            $('.notif-popup').toggle();
            });
        $('#show').click(function() {
            $('.notif-popup').hide();
            });
        $('#show2').click(function() {
            $('.notif-popup').hide();
            });
        });

$(document).ready(function(){
        $('#show').click(function() {
            $('.useroptions').toggle();
            });
        $('#show1').click(function() {
            $('.useroptions').hide();
            });
        $('#show2').click(function() {
            $('.useroptions').hide();
            });
        $('#show3').click(function() {
            $('.useroptions').hide();
            });
        $('#show4').click(function() {
            $('.useroptions').hide();
            });
        });

$(document).ready(function(){
        $('#show2').click(function() {
            $('.modal-select-event').show();
            });
        $('#close-selevent').click(function() {
            $('.modal-select-event').hide();
            });
        $('#resp-close-selevent').click(function() {
            $('.modal-select-event').hide();
            });
        });

$(document).ready(function(){
        $('#show3').click(function() {
            $('.section-content-preferences').show();
            });
        $('#show4').click(function() {
            $('.section-content-preferences').hide();
            });
        });

$(document).ready(function(){
        $('#show4').click(function() {
            $('.section-content-account').show();
            });
        $('#show3').click(function() {
            $('.section-content-account').hide();
            });
        });

