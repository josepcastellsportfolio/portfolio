/* Aquí comença el JavaScript de Core Files */

$(document).ready(function(){
        $('#room_centralperk').click(function() {
            $('#sideroom_centralperk').show();
            });
        $('#close_sideroom_centralperk').click(function() {
            $('#sideroom_centralperk').hide();
            });
        });

$(document).ready(function(){
        $('#session_cookingwhithmonica').click(function() {
            $('#sidesession_cookingwhithmonica').show();
            });
        $('#close_session_cookingwhithmonica').click(function() {
            $('#sidesession_cookingwhithmonica').hide();
            });
        });




        ea-session-container-sidebar