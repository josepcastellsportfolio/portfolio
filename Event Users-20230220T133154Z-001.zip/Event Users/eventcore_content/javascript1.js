/* Aquí comença el JavaScript de Core Files */

$(document).ready(function(){
        $('#row1_options_openpop').click(function() {
            $('#row1_options_pop').toggle();
            });
        });
$(document).ready(function(){
    $('#row2_options_openpop').click(function() {
        $('#row2_options_pop').toggle();
        });
    });
$(document).ready(function(){
    $('#row3_options_openpop').click(function() {
        $('#row3_options_pop').toggle();
        });
    });
$(document).ready(function(){
    $('#row4_options_openpop').click(function() {
        $('#row4_options_pop').toggle();
        });
    });
$(document).ready(function(){
    $('#row5_options_openpop').click(function() {
        $('#row5_options_pop').toggle();
        });
    });
$(document).ready(function(){
    $('#row6_options_openpop').click(function() {
        $('#row6_options_pop').toggle();
        });   
    });
$(document).ready(function(){
    $('#row7_options_openpop').click(function() {
        $('#row7_options_pop').toggle();
        });   
});
          
$(document).ready(function(){
    $('#table-view').click(function(){
        $('#coreusers-table').toggle();
        $('#cards-container').toggle();
       });
       $('#card-list-view').click(function(){
        $('#cards-container').toggle();
        $('#coreusers-table').toggle();
       });
});

$(document).ready(function(){
        $('#open_ec_fileoptions').click(function() {
            $('.ec-file-options-pop').toggle();
            });
        });

$(document).ready(function(){
        $('#eu_close_sidebar').click(function() {
            $('.eventcore-sidebar-resp').hide();
            });
        });

$(document).ready(function(){
        $('#ec_close_sidebar_addfile').click(function() {
            $('.eventcore-sidebar-resp').hide();
            });
        });

$(document).ready(function(){
        $('#eu_open_options_pop_selcheck').click(function() {
            $('#eu_options_pop_selcheck').toggle();
            });
        });

$(document).ready(function(){
        $('#eu_open_extensopt').click(function() {
            $('#eu_extensopt').toggle();
            });
        $('#eu_extens_jpg').click(function() {
            $('#eu_extensopt').hide();
            });
        $('#eu_extens_mp4').click(function() {
            $('#eu_extensopt').hide();
            });
        $('#eu_extens_gif').click(function() {
            $('#eu_extensopt').hide();
            });
        });


/* Aquí comença el JavaScript de Programme Error */
$(document).ready(function(){
        $('#eu_close_sidebar').click(function() {
            $('.eventcore-sidebar-resp').hide();
            });
        });

$(document).ready(function(){
        $('#open_popup_confirm_progerror').click(function() {
            $('#popup_confirm_progerror').show();
            });
        $('#delete_progerror').click(function() {
            $('#popup_confirm_progerror').hide();
            });
        $('#cancel_delete_progerror').click(function() {
            $('#popup_confirm_progerror').hide();
            });
        });

$(document).ready(function(){
        $('#open_popup_confirm_progerror_pres').click(function() {
            $('#popup_confirm_progerror_pres').show();
            });
        $('#delete_progerror_pres').click(function() {
            $('#popup_confirm_progerror_pres').hide();
            });
        $('#cancel_delete_progerror_pres').click(function() {
            $('#popup_confirm_progerror_pres').hide();
            });
        });

        selectCard = (card) => {
            let sidebar = document.getElementById('main-sidebar');
            if(card.classList.contains('eu-cardSelected')){
                card.classList.remove('eu-cardSelected');
                sidebar.style.display='none';
            }
            else{
                card.classList.add('eu-cardSelected');
                sidebar.style.display='flex';
            }
        }

            
        window.onload = () => {
            
            let list = document.getElementsByClassName("eu-border-bottom-core");
            document.getElementById('page1').focus()

            let row_management = (list.length > 12) ?
            () => {  for (let item of list) {

                if(item.id > 12) {
                    item.style.display = "none";   
                }            
            }}
            : () => {  for (let item of list) {


                item.style.display = "table-row";
            }}
            row_management();
        }

        let first_rows = (list) => {

            for (let item of list) {

                if(item.id <= 12){
                    document.getElementById('page1').focus();
                    item.style.display = "table-row";
                }
                else{
                    item.style.display="none";
                }
            }

        }

        let second_rows = (list) => {

            for (let item of list) {

                if(item.id > 12){     
                    document.getElementById('page2').focus();
                    item.style.display= "table-row";
                }
                else {
                    item.style.display= "none";
                }
            }
        }
        
       let button_action = (param) => {

            let list = document.getElementsByClassName("eu-border-bottom-core");

            if(typeof param === "string") {
                
                if(param === "previous") {
                    document.getElementById('page1').focus()
                    first_rows(list);
                }   
                else {
                    console.log("next")
                    second_rows(list);
                }
            }
            else  {
                if(param.id==="page1"){
                    first_rows(list);
                }
                if(param.id==="page2"){
                    second_rows(list);
                }
            }
        }
        

         show_sidebar = (element) => {

            let sidebar = document.getElementById('main-sidebar');
            let ecContainer = document.getElementById('eccont');
            console.log(sidebar);
            if (element.classList.contains('selected')){
                sidebar.style.display='flex';


            }
            else{
                sidebar.style.display='none';
    
            }
         }
        
        const image_input = document.querySelector("#image-input");

        image_input.addEventListener("change", function() {
            const reader = new FileReader();
            reader.addEventListener("load", () => {
                const uploaded_image = reader.result;
                document.querySelector("#display-image").style.backgroundImage = `url(${uploaded_image})`;
            });
            reader.readAsDataURL(this.files[0]);
        });
